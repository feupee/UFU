package Dados;

public class DadosCompras {

}
